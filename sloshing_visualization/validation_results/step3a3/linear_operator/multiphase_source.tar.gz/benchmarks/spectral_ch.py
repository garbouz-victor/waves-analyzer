"""STEP 3A.3 staged analysis. Historical inputs are always read-only."""
import csv
import json
from pathlib import Path
import tarfile
import time
import numpy as np
from ..linearized_ch import array_hash, json_hash

RESULTS = Path("validation_results/step3a3")
EQUILIBRIUM = Path("validation_results/step3a2/equilibrium60/prepared_symmetric")
OLD_BUMP = Path("validation_results/step3a2/equilibrium_perturbation/be_dt_1e-5")


def read_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+"\n")


def reserve(name):
    output = RESULTS/name
    output.mkdir(parents=True, exist_ok=False)
    write_json(output/"status.json", {"status": "running", "stage": name})
    source = Path(__file__).resolve().parents[1]
    with tarfile.open(output/"multiphase_source.tar.gz", "x:gz") as archive:
        for path in sorted(source.rglob("*.py")):
            archive.add(path, arcname=str(path.relative_to(source)))
    return output


def scientific_input():
    from ..config import ModelConfig
    from ..solver import CHNSSolver
    from ..equilibrium import load_prepared, zero_mass_perturbations
    from ..provenance import run_provenance
    meta = read_json(EQUILIBRIUM/"prepared.json")
    s = CHNSSolver(ModelConfig(**meta["config"]))
    eq = load_prepared(EQUILIBRIUM, s, meta["target_mass"])
    s.initialize_prepared_equilibrium(eq)
    phi = s.state.sub(2).collapse()
    old = read_json(OLD_BUMP/"perturbation.json")
    if old["delta"] != 1e-3:
        raise ValueError("Historical amplitude changed")
    frozen = RESULTS/"linear_operator/inputs.npz"
    if frozen.exists():
        with np.load(frozen) as data:
            psi = data["psi"].copy()
            initial = data["initial_phi"].copy()
            if not np.array_equal(data["phi_eq"], phi.x.array):
                raise ValueError("Frozen equilibrium bytes mismatch")
        recovery = "load frozen, historical-hash-verified coefficient arrays"
    else:
        field, _ = zero_mass_perturbations(s, phi)["smooth_bulk"]
        psi = field.x.array.copy()
        initial = phi.x.array+1e-3*psi
        recovery = "replay unchanged historical initializer; require BOTH archived coefficient hashes"
    if (array_hash(psi) != old["psi_coefficient_sha256"] or
            array_hash(initial) != old["initial_phi_coefficient_sha256"] or
            not np.array_equal(initial, phi.x.array+1e-3*psi)):
        raise ValueError("STOP: perturbation/initial phi not coefficientwise identical to STEP 3A.2")
    provenance = {**run_provenance(s), "equilibrium_fingerprint": meta["fingerprint"],
        "perturbation_coefficient_sha256": array_hash(psi), "initial_phi_sha256": array_hash(initial),
        "quadrature_degree": s.config.quadrature_degree, "mobility": s.config.mobility,
        "target_mass": meta["target_mass"], "input_recovery": recovery}
    return s, phi, psi, initial, provenance


def historical_fast_balance():
    rows = []
    times_per_step = []
    root = OLD_BUMP.parent
    for name in ("be_dt_1e-5", "be_dt_5e-6", "be_dt_2_5e-6"):
        summary = read_json(root/name/"summary.json")
        times_per_step.append(summary["runtime_s"]/summary["accepted_steps"])
        with (root/name/"history.csv").open() as stream:
            old = list(csv.DictReader(stream))
        for row in old[:4]:
            values = {k: float(row[k]) for k in ("time", "CH_dissipation", "viscous_dissipation", "slip_dissipation", "E_kin")}
            values.update(run=name,
                hydrodynamic_power_over_CH=(values["viscous_dissipation"]+values["slip_dissipation"])/values["CH_dissipation"],
                kinetic_over_initial_excess=values["E_kin"]/5.542888467657825e-8)
            rows.append(values)
    return {"measurements": rows, "max_hydrodynamic_power_over_CH": max(r["hydrodynamic_power_over_CH"] for r in rows),
        "max_kinetic_over_initial_excess": max(r["kinetic_over_initial_excess"] for r in rows),
        "historical_seconds_per_step": times_per_step,
        "cost_seconds_per_step_conservative": max(times_per_step),
        "scope": "CH-dominated stiff subsystem planner; final qualification remains FULL nonlinear CHNS"}


def operator_stage():
    from scipy.sparse import save_npz
    from ..linearized_ch import assemble_linearized_ch, NonlinearCHRate, ALGORITHM_VERSION
    output = reserve("linear_operator")
    started = time.perf_counter()
    try:
        s, phi, psi, initial, provenance = scientific_input()
        np.savez_compressed(output/"inputs.npz", phi_eq=phi.x.array, psi=psi, initial_phi=initial)
        provenance["spectrum_algorithm_version"] = ALGORITHM_VERSION
        op = assemble_linearized_ch(s, phi, provenance)
        checks = op.matrix_checks()
        nonlinear = NonlinearCHRate(s, phi.function_space, op)
        finite = nonlinear.finite_difference_checks(phi.x.array, psi)
        # Additional independent FE directions, not only the seed.
        rng = np.random.default_rng(3302)
        random_finite = []
        for _ in range(3):
            q = op.project(rng.normal(size=op.size)); q /= max(abs(q))
            random_finite.append(nonlinear.finite_difference_checks(phi.x.array, q))
        balance = historical_fast_balance()
        q0 = op.project(psi)
        timescale = op.energy(q0)/op.power(q0)
        gates = {"mass_conservation": checks["max_relative_mass_defect"] <= 1e-11,
            "roundoff_projection": checks["max_projection_relative_defect"] <= 1e-11,
            "matrix_symmetry": max(checks["frobenius_symmetry_defects"].values()) <= 1e-11 and
                               max(checks["bilinear_symmetry_defects"].values()) <= 1e-11,
            "Hessian_linearization": all(r[-1]["hessian_relative_M_dual_error"] <= 1e-6 for r in [finite]+random_finite),
            "nonlinear_rate_linearization": all(r[-1]["central_rate_relative_L2_error"] <= 1e-6 for r in [finite]+random_finite),
            "linear_energy_identity": checks["max_relative_energy_identity_defect"] <= 1e-10,
            "CH_dominated": balance["max_hydrodynamic_power_over_CH"] <= 1e-4 and balance["max_kinetic_over_initial_excess"] <= 1e-4,
            "initial_timescale_agreement": abs(timescale/4.862048987156724e-7-1) <= 1e-2}
        for name in ("M0", "K", "H"):
            save_npz(output/(name+".npz"), getattr(op, name))
        np.savez_compressed(output/"mass.npz", mass=op.mass)
        write_json(output/"operator_identity.json", {**op.identity, "fingerprint": op.fingerprint})
        from petsc4py import PETSc
        import scipy, dolfinx
        import importlib.util
        stack = {"dolfinx": dolfinx.__version__, "petsc": PETSc.Sys.getVersion(), "scipy": scipy.__version__,
                 "slepc4py_available": importlib.util.find_spec("slepc4py") is not None}
        if stack["slepc4py_available"]:
            from slepc4py import SLEPc
            stack["slepc"] = SLEPc.Sys.getVersion()
        result = {"status": "complete", "qualification_status": "passed" if all(gates.values()) else "failed",
            "gates": gates, "provenance": provenance, "operator_fingerprint": op.fingerprint,
            "stack": stack, "phase_dofs": op.size, "matrix_checks": checks,
            "smooth_bump_finite_differences": finite, "random_finite_differences": random_finite,
            "CH_dominated_justification": balance, "initial_linear_E2_at_delta": 1e-6*op.energy(q0),
            "initial_linear_D2_at_delta": 1e-6*op.power(q0), "tau_E_linear": timescale,
            "historical_tau_E": 4.862048987156724e-7,
            "old_dt_over_tau_E": [dt/4.862048987156724e-7 for dt in (1e-5, 5e-6, 2.5e-6)],
            "raw_psi_mass": float(op.mass @ psi), "projected_psi_mass": float(op.mass @ q0),
            "runtime_s": time.perf_counter()-started}
        write_json(output/"status.json", result)
        print(json.dumps(result, indent=2), flush=True)
        return result
    except BaseException as error:
        write_json(output/"failure.json", {"status": "failed", "error": str(error), "runtime_s": time.perf_counter()-started})
        raise


def load_operator():
    from scipy.sparse import load_npz
    from ..linearized_ch import LinearizedCH
    folder = RESULTS/"linear_operator"
    result = read_json(folder/"status.json")
    if result.get("qualification_status") != "passed":
        raise ValueError("STOP: linear operator prerequisite failed")
    with np.load(folder/"mass.npz") as data:
        mass = data["mass"].copy()
    op = LinearizedCH(*(load_npz(folder/(name+".npz")) for name in ("M0", "K", "H")),
        mobility=result["provenance"]["mobility"], mass_vector=mass, provenance=result["provenance"])
    if op.fingerprint != result["operator_fingerprint"]:
        raise ValueError("Saved operator fingerprint mismatch")
    with np.load(folder/"inputs.npz") as data:
        psi = data["psi"].copy()
    if array_hash(psi) != result["provenance"]["perturbation_coefficient_sha256"]:
        raise ValueError("Saved perturbation hash mismatch")
    return op, op.project(psi), result
