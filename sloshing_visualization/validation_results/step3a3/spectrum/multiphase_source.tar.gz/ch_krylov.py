"""Mass-inner-product Arnoldi with reorthogonalization and explicit defects.

This analysis module accepts an operator with apply/project/M0/norm methods.
Only the projected Hessenberg exponential is dense, never the full CH matrix.
"""
import numpy as np
from scipy.linalg import eig, expm
from .linearized_ch import array_hash, json_hash

ALGORITHM_VERSION = "M-arnoldi-two-pass-mgs-expm-v1"


class MassArnoldi:
    def __init__(self, operator, seed, max_dimension=1024):
        self.operator = operator
        self.seed = operator.project(np.asarray(seed, dtype=float))
        self.beta = operator.norm(self.seed)
        if not np.isfinite(self.beta) or self.beta == 0:
            raise ValueError("Nonzero finite mass-zero Arnoldi seed required")
        capacity = min(max_dimension, operator.size-1)
        self.V = np.zeros((operator.size, capacity+1), order="F")
        self.MV = np.zeros_like(self.V, order="F")
        self.hessenberg = np.zeros((capacity+1, capacity))
        self.V[:, 0] = self.seed/self.beta
        self.MV[:, 0] = operator.M0 @ self.V[:, 0]
        self.dimension = 0
        self.breakdown = False

    def extend(self, dimension, monitor=None):
        target = min(dimension, self.hessenberg.shape[1])
        for j in range(self.dimension, target):
            if self.breakdown:
                break
            w = self.operator.apply(self.V[:, j])
            initial_norm = self.operator.norm(w)
            for _ in range(2):
                w = self.operator.project(w)
                for i in range(j+1):
                    hij = float(self.MV[:, i] @ w)
                    self.hessenberg[i, j] += hij
                    w -= hij*self.V[:, i]
            w = self.operator.project(w)
            beta = self.operator.norm(w)
            self.hessenberg[j+1, j] = beta
            self.dimension = j+1
            if beta <= 64*np.finfo(float).eps*max(initial_norm, 1.):
                self.breakdown = True
            else:
                self.V[:, j+1] = w/beta
                self.MV[:, j+1] = self.operator.M0 @ self.V[:, j+1]
            if monitor:
                monitor(self.dimension)
        return self.dimension

    def projected(self, dimension=None):
        m = self.dimension if dimension is None else dimension
        if m > self.dimension or m < 1:
            raise ValueError("Unbuilt Arnoldi dimension")
        return self.hessenberg[:m, :m]

    def diagnostics(self, dimension=None):
        m = self.dimension if dimension is None else dimension
        V, MV = self.V[:, :m], self.MV[:, :m]
        orth = np.linalg.norm(V.T @ MV-np.eye(m), ord=2)
        # Check the actual full-operator relation on deterministic columns,
        # including the terminal residual, not merely the stored recurrence.
        columns = sorted(set((0, m//2, m-1)))
        residuals = []
        for j in columns:
            actual = self.operator.apply(V[:, j])
            expected = self.V[:, :m+1] @ self.hessenberg[:m+1, j]
            residuals.append(self.operator.norm(actual-expected)/max(self.operator.norm(actual), 1e-300))
        return {"dimension": m, "orthogonality_defect": float(orth),
                "max_checked_Arnoldi_relative_residual": float(max(residuals)),
                "checked_columns": columns, "terminal_residual_norm": float(self.hessenberg[m, m-1]),
                "maximum_basis_mass": float(np.max(abs(self.operator.mass @ V))),
                "happy_breakdown": bool(self.breakdown),
                "basis_sha256": array_hash(V), "Hessenberg_sha256": array_hash(self.projected(m))}

    def ritz(self, dimension=None, previous=None, dissipative_significance=False):
        m = self.dimension if dimension is None else dimension
        values, vectors = eig(self.projected(m))
        weights = np.linalg.solve(vectors, np.eye(m)[:, 0])
        previous_values = np.array([complex(r["real"], r["imag"]) for r in previous]) if previous else None
        power0 = self.operator.power(self.seed) if dissipative_significance else None
        rows = []
        for index in np.argsort(values.real)[::-1]:
            value, z = values[index], vectors[:, index]
            residual = abs(self.hessenberg[m, m-1]*z[-1])/(max(abs(value), 1.)*np.linalg.norm(z))
            change = (float(min(abs(previous_values-value))/max(abs(value), 1.)) if previous is not None else None)
            significance = float(abs(weights[index])*np.linalg.norm(z))
            power_fraction = None
            if dissipative_significance:
                vector = self.V[:, :m] @ z
                power_fraction = float(self.beta**2*abs(weights[index])**2*self.operator.power(vector)/max(power0, 1e-300))
            significant = significance >= 1e-8 or (power_fraction is not None and power_fraction >= 1e-8)
            converged = residual <= 1e-6 and change is not None and change <= 1e-6
            rows.append({"mode": int(index), "real": float(value.real), "imag": float(value.imag),
                "tau_s": float(-1/value.real) if value.real < 0 else None,
                "relative_Ritz_residual": float(residual), "last_level_relative_change": change,
                "seed_L2_significance": significance, "initial_power_self_fraction": power_fraction,
                "significant": bool(significant), "converged": bool(converged),
                "old_z_finest": float(abs(value.real)*2.5e-6)})
        return rows

    def reference(self, times, dimension=None):
        m = self.dimension if dimension is None else dimension
        h = self.projected(m)
        reduced = np.array([self.beta*expm(float(t)*h)[:, 0] for t in times])
        states = reduced @ self.V[:, :m].T
        energies, powers, defects = [], [], []
        for q, c in zip(states, reduced):
            rate = self.V[:, :m] @ (h @ c)
            energy = self.operator.energy(q)
            power = self.operator.power(q)
            defect = float(q @ (self.operator.H @ rate)+power)
            energies.append(energy); powers.append(power)
            defects.append(abs(defect)/max(abs(power), 1e-300))
        return {"times": np.asarray(times), "states": states, "reduced": reduced,
                "energy": np.array(energies), "power": np.array(powers),
                "projected_energy_identity_relative_defect": np.array(defects)}

    def fingerprint(self, dimension=None):
        return json_hash({"algorithm_version": ALGORITHM_VERSION, "operator": self.operator.fingerprint,
                          "seed": array_hash(self.seed), **self.diagnostics(dimension)})


def compare_references(operator, coarse, fine):
    if not np.array_equal(coarse["times"], fine["times"]):
        raise ValueError("Krylov levels require identical reference times")
    initial = operator.norm(fine["states"][0])
    fields = [operator.norm(a-b)/max(operator.norm(b), 1e-14*initial)
              for a, b in zip(coarse["states"], fine["states"])]
    result = {"max_relative_L2_difference": float(max(fields)), "relative_L2_by_time": fields}
    for key in ("energy", "power"):
        relative = abs(coarse[key]-fine[key])/np.maximum(abs(fine[key]), 1e-14*abs(fine[key][0]))
        result["max_relative_"+key+"_difference"] = float(max(relative))
    return result
