"""STEP3A4 role-separated, append-only scientific stages. Historical inputs read-only."""
import hashlib
import json
import os
from pathlib import Path
import tarfile
import time
import numpy as np
from ..ch_validation_policy import (ValidationPolicy, AnalysisBudget, LINEAR_LIMITS,
    authorizations, linear_gates, run_sparse_analysis)
from ..linearized_ch import json_hash, array_hash
from ..performance import Performance, petsc_events
from . import spectral_ch as historical

RESULTS = Path("validation_results/step3a4")
POLICY = ValidationPolicy()
ACTIVE_OUTPUT = None


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+"\n")


def read_json(path):
    return json.loads(Path(path).read_text())


def freeze_policy():
    folder = RESULTS/"policy"
    folder.mkdir(parents=True, exist_ok=True)
    record = {"policy": POLICY.record(), "policy_sha256": POLICY.fingerprint,
        "design_sha256": hashlib.sha256(Path("STEP3A4_DESIGN.md").read_bytes()).hexdigest()}
    path = folder/"policy.json"
    if path.exists():
        if read_json(path) != record:
            raise ValueError("STOP: frozen STEP3A4 policy or design changed")
    else:
        write_json(path, record)
    return record


def reserve(name):
    global ACTIVE_OUTPUT
    output = RESULTS/name
    if RESULTS.resolve() not in output.resolve().parents:
        raise ValueError("Historical/external output paths forbidden; require STEP3A4 subdirectory")
    policy = freeze_policy()
    output.mkdir(parents=True, exist_ok=False)
    ACTIVE_OUTPUT = output
    write_json(output/"status.json", {"status": "running", "stage": name})
    source = Path(__file__).resolve().parents[1]
    with tarfile.open(output/"multiphase_source.tar.gz", "x:gz") as archive:
        for path in sorted(source.rglob("*.py")):
            archive.add(path, arcname=str(path.relative_to(source)))
    from ..provenance import source_hash
    old = read_json(historical.RESULTS/"linear_operator/status.json")["provenance"]
    provenance = {"git_commit": os.environ.get("STEP3_GIT_COMMIT", "unavailable"),
        "docker_image_digest": os.environ.get("STEP3_DOCKER_IMAGE_DIGEST", "unavailable"),
        "multiphase_source_sha256": source_hash(),
        "source_archive_sha256": hashlib.sha256((output/"multiphase_source.tar.gz").read_bytes()).hexdigest(),
        "historical_input_provenance": old, **policy}
    for key in ("equilibrium_fingerprint", "perturbation_coefficient_sha256", "initial_phi_sha256",
                "mesh_fingerprint", "quadrature_degree", "mobility", "target_mass"):
        provenance[key] = old[key]
    write_json(output/"provenance.json", provenance)
    return output


def analysis_used():
    total = 0.
    for path in RESULTS.rglob("timing.json"):
        record = read_json(path)
        if record.get("analysis_budget_charged", False):
            total += record["wall_s"]
    return total


def load_reference():
    from ..ch_timestep_planner import ReducedCHReference
    op, _, operator_record, reference_record, basis, _ = historical.qualified_reference()
    V = basis["V"]
    chemical = op.mass_solve(op.H @ V)
    ref = ReducedCHReference(basis["projected_L"], V.T @ (op.H @ V),
        op.mobility*chemical.T @ (op.K @ chemical),
        float(basis["beta"])*np.eye(V.shape[1])[:, 0], V.T @ (op.M0 @ V))
    fps = {"operator": op.fingerprint,
        "equilibrium": operator_record["provenance"]["equilibrium_fingerprint"],
        "perturbation": operator_record["provenance"]["perturbation_coefficient_sha256"],
        "Krylov": reference_record["Krylov_sha256"]}
    return op, ref, V, fps, reference_record


def profile_initial():
    """No time advance: never scientific temporal evidence."""
    from dolfinx import fem
    from petsc4py import PETSc
    from ..diagnostics import Diagnostics, interface_resolution
    from ..be_work_diagnostics import BEWorkDiagnostics
    from .contact_angle import observe
    output = reserve("performance/initial_profile")
    perf = Performance()
    PETSc.Log.begin()
    with perf.measure("initialization"):
        s, phi_eq, psi, initial, provenance = historical.scientific_input()
        field = fem.Function(phi_eq.function_space)
        field.x.array[:] = initial; field.x.scatter_forward()
        s.initialize(field)
        if array_hash(s.state.sub(2).collapse().x.array) != provenance["initial_phi_sha256"]:
            raise ValueError("Initial phi hash changed")
        diagnostic, work = Diagnostics(s), BEWorkDiagnostics(s)
    samples = []
    for _ in range(3):
        with perf.measure("diagnostics"):
            row = diagnostic.measure()
        with perf.measure("interface_resolution"):
            resolution = interface_resolution(s)
        with perf.measure("contact_geometry"):
            geometry = observe(s)  # includes its own resolution; disclosed in result
        with perf.measure("BE_work"):
            audit = work.measure(0., row, row)
        sample = {"row": row, "resolution": resolution, "geometry": geometry, "work": audit}
        with perf.measure("filesystem_write"):
            with (output/"samples.jsonl").open("a") as stream:
                stream.write(json.dumps(sample)+"\n")
        samples.append(sample)
    timing = {**perf.snapshot(), "analysis_budget_charged": True,
        "PETSc": petsc_events(), "time_advance": False,
        "geometry_timer_includes_duplicate_resolution": True}
    write_json(output/"timing.json", timing)
    result = {"status": "complete", "qualification_status": "profile_only",
        "provenance": provenance, "initial": samples[0], "timing": timing}
    write_json(output/"status.json", result)
    print(json.dumps({"stage": "initial_profile", "timing": timing["categories"]}), flush=True)
    return result


def sparse_stage(optimized=False):
    from petsc4py import PETSc
    from ..ch_timestep_planner import validate_plan, verify_full_sparse_schedule
    folder = "optimized_plan" if optimized else "baseline_plan"
    output = reserve("linear_sparse/"+folder)
    perf, budget = Performance(), AnalysisBudget(analysis_used())
    PETSc.Log.begin()
    try:
        with perf.measure("initialization"):
            op, ref, V, fps, ref_record = load_reference()
            path = (RESULTS/"schedule_optimization/optimized_plan.json" if optimized else
                    historical.RESULTS/"stiff_bump/planner/timestep_plan.json")
            plan = read_json(path)
            validate_plan(plan, fps)
            reduced_ok = all(linear_gates(plan["predicted_errors"]).values())
            op.resolvent_backend, op.performance = "petsc_mumps", perf
        write_json(output/"input_plan.json", plan)
        steps = sum(b["steps"] for b in plan["blocks"])
        def monitor(row):
            with perf.measure("filesystem_write"):
                with (output/"progress.jsonl").open("a") as stream:
                    stream.write(json.dumps(row)+"\n")
                write_json(output/"timing_progress.json", perf.snapshot())
            print("Full sparse "+folder+" "+json.dumps(row), flush=True)
            # A bounded measured forecast, not the historical nonlinear timing.
            records = perf.records
            done = len(records["linear_solve"])
            per_step = sum(r["wall_s"] for key in ("linear_solve", "diagnostics")
                           for r in records[key])/max(done, 1)
            factors = records["factorization_setup"]
            per_factor = sum(r["wall_s"] for r in factors)/max(len(factors), 1)
            budget.check(per_step*(steps-done)+per_factor*(len(plan["blocks"])-len(factors)))
        verification = run_sparse_analysis(lambda: verify_full_sparse_schedule(
            op, ref, V, plan["blocks"], monitor, performance=perf, check_budget=budget.check),
            reduced_pass=reduced_ok, analysis_budget=budget)
        gates = linear_gates(verification, full_sparse=True)
        with perf.measure("filesystem_write"):
            write_json(output/"verification.json", verification)
        status = {"status": "complete", "qualification_status": "passed" if all(gates.values()) else "failed",
            "benchmark": "full sparse LINEAR BE, not nonlinear isolated CH or CHNS",
            "steps": steps, "gates": gates, "plan_sha256": plan["plan_sha256"],
            "input_fingerprints": fps, "rational_reference_record": ref_record,
            "initial_D2": op.power(V @ ref.seed), "initial_E2": op.energy(V @ ref.seed),
            "errors": {k: v for k, v in verification.items() if k not in ("history", "blocks")},
            "reduced_errors": plan["predicted_errors"],
            "authorizations": authorizations(reduced=reduced_ok, sparse=all(gates.values()))}
        write_json(output/"status.json", status)
        print(json.dumps({"stage": folder, "gates": gates, "errors": status["errors"]}), flush=True)
        return status
    except Exception as exc:
        write_json(output/"status.json", {"status": "stopped", "qualification_status": "failed",
            "reason": str(exc), "authorizations": authorizations()})
        raise
    finally:
        timing = {**perf.snapshot(), "analysis_budget_charged": True, "PETSc": petsc_events(),
            "distinct_factors": len({r["dt"] for r in perf.records["factorization_setup"]})}
        write_json(output/"timing.json", timing)


STAGES = {"profile": profile_initial, "baseline_sparse": sparse_stage,
          "optimized_sparse": lambda: sparse_stage(True)}
